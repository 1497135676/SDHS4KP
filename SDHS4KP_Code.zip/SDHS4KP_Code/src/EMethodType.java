public enum EMethodType {
	SIMPLIFIED_HS
}
