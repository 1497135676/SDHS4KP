
public enum EPitchOrderType {
    DENSITY, PROFIT, HYBRID
}
