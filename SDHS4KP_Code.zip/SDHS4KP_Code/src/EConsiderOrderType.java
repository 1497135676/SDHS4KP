
public enum EConsiderOrderType {
    HEURISTIC, NATURAL
}
